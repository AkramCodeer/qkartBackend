const httpStatus = require("http-status");
const userService = require("./user.service");
const ApiError = require("../utils/ApiError");

/**
 * Login with username and password
 * - Utilize userService method to fetch user object corresponding to the email provided
 * - Use the User schema's "isPasswordMatch" method to check if input password matches the one user registered with (i.e, hash stored in MongoDB)
 * - If user doesn't exist or incorrect password,
 * throw an ApiError with "401 Unauthorized" status code and message, "Incorrect email or password"
 * - Else, return the user object
 *
 * @param {string} email
 * @param {string} password
 * @returns {Promise<User>}
 */
const loginUserWithEmailAndPassword = async (email, password) => {
  try {
    // Step 1: Fetch user by email using userService
    const user = await userService.getUserByEmail(email);

    // Step 2: Check if the user exists
    if (!user) {
      throw new ApiError(401, 'Incorrect email or password');
    }

    // Step 3: Check if the password matches
    const isPasswordMatch = await user.isPasswordMatch(password);

    if (!isPasswordMatch) {
      throw new ApiError(401, 'Incorrect email or password');
    }

    // Step 4: Password is correct, return the user object
    return user;
  } catch (error) {
    // Handle errors here, log them, etc.
    throw error;
  }
};

module.exports = {
  loginUserWithEmailAndPassword,
};
